Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/how-to-create-a-php-event-calendar-with-fullcalendar-js-library/


## Instructions -
1. Import the attached events.sql file in your database.
2. Update database configuration in config.php