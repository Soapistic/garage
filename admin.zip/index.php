<?php 
header('Location: ./admin')
?>